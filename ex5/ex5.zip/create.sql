create table sales
(
    TranscationNo varchar(50),
    Date          varchar(100),
    ProductNo     varchar(100),
    ProductName   varchar(100),
    Price         varchar(100),
    Quantity      varchar(100),
    CustomerNo    varchar(100),
    Country       varchar(100)
);

